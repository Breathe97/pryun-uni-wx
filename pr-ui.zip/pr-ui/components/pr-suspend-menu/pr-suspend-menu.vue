<template>
	<view>
		<view class="pr-suspend-menu">

		</view>
	</view>
</template>

<script setup lang="ts">
</script>

<style scoped>
</style>
